<?php

return [
    "cancel" => "Cancel",
    "confirm" => "Confirm",
    "member" => [
    	"delete"=>[
        	"title" => "Xóa người dùng",
        	"body" => "Bạn có chắc muốn xóa người dùng này?"
    	],
    	"block"=>[
        	"title" => "Khóa người dùng",
        	"body" => "Bạn có chắc muốn xóa người dùng này?"
    	]
    ],
    "group" => [
        "delete"=>[
            "title" => "Xóa nhóm người dùng",
            "body" => "Bạn có chắc muốn xóa nhóm người dùng này?"
        ],
    ],
];
