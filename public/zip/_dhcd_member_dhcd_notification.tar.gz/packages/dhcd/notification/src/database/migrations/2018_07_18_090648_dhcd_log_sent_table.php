<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DhcdLogSentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dhcd_log_sent', function (Blueprint $table) {
            $table->increments('log_sent_id');
            $table->integer("group_id", false, true)->comment('nhom nguoi dung duoc gui');
            $table->integer("notification_id", false, true)->comment('id thong bao gui');
            
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dhcd_log_sent');
    }
}
