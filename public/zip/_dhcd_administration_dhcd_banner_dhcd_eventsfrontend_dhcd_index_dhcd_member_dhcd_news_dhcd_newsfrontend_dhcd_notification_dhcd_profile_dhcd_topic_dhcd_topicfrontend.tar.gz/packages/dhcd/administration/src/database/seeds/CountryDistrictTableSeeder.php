<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class CountryDistrictTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('dhcd_commune_guild')->insert([
        //     'user_id'=>'Thể thao',
        //     'provine_city_id'=>'Thể thao',
        //     'name'=>0,
        //     'alias'=>0,
        //     'type'=>'the-thao',
        //     'name_with_type'=>1,
        //     'path'=>1,
        //     'path_with_type'=>1,
        //     'code'=>1,
        //     'created_at' => new DateTime(),
        //     'updated_at' => new DateTime(),
        // ]);
    }
}
