<?php

return [
    "cancel" => "Hủy",
    "confirm" => "Chấp nhận",
    "notification" => [
    	"delete"=>[
        	"title" => "Xóa thông báo",
        	"body" => "Bạn có chắc muốn xóa thông báo này?"
    	]
    ],
];
