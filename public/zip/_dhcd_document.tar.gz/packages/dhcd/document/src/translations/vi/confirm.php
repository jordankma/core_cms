<?php

return [
    "cancel" => "Cancel",
    "confirm" => "Confirm",
    "document_cate" => [
    	"delete_member"=>[
        	"title" => "Xóa người dùng",
        	"body" => "Bạn có chắc muốn xóa người dùng này?"
    	]
    ]
];
