$(document).ready(function() {
    $('#cate').multiselect({
        buttonWidth: '367px',
        nonSelectedText: 'Chọn danh mục',
        enableFiltering: true,
    });
});